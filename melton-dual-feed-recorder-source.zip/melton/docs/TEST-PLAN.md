# Test plan (none of these have been run yet)

Setup: Camera 1/2/3 scenes, a master scene containing a nested camera scene + station logo + lower third + ticker. In the dock's Graphics exclusion tab tick the logo, lower third and ticker. Settings: 1080p30 or 720p30, MKV, linked mode. OBS recording path = Melton folder, filename `DIRTY_...`.

| # | Procedure | Pass criteria |
|---|-----------|---------------|
| 1 | Record. Cut Cam1 -> Cam2 -> Cam3 -> Cam1 at known times. | Both files show the same camera at the same moments (scrub both side by side). |
| 2 | Add station logo to the master scene (excluded). Record. | Logo visible in DIRTY, absent in CLEAN, camera content identical. |
| 3 | Show/hide the lower third repeatedly. | Visible in DIRTY only, never flashes in CLEAN. |
| 4 | 20+ rapid cuts between cameras (Program in Cut mode, then Fade 300 ms). | CLEAN never freezes or shows a wrong camera; no black frames; log has no "held" spam. |
| 5 | Use Fade, Slide, Stinger, and a per-scene transition override. Then try T-bar (studio mode) and Fade-to-Black. | Fade/Slide/Stinger/override: CLEAN shows the same transition type. T-bar/FTB: CLEAN cuts (documented), never wrong scene or black. |
| 6 | Speak/play a tone with a visible clap on camera. | Same audio in both files; clap and sound aligned in both. Check `ffprobe` shows 1 AAC track in CLEAN. |
| 7 | Record 30+ min at target settings. | Dock shows 0 skipped/dropped frames; audio drift vs DIRTY < 1 frame at the end; OBS stats/Task Manager memory flat; `ffprobe -v error` clean on both files. |
| 8 | Start/stop (both and clean-only) 10 times. Also stop OBS (File -> Exit) while recording. | No overwritten files (names `_2`, `_3`), all files playable, OBS exits without hanging, log shows "Clean recording finalised". |

Also check: rename an excluded source (exclusion follows it), delete it (shown as "(missing)" in the list, no crash), switch scene collection while idle, fill the destination disk to <2 GB (start refused with message) and <300 MB during recording (clean stops, file intact).

Useful log lines (OBS -> Help -> Log Files): `Clean mirror ready: N scene(s) mirrored`, `Clean renderer started`, `Clean recording starting/started/finalised`.
