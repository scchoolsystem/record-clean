# Troubleshooting

* **Dock missing**: View -> Docks -> MELTON DUAL FEED. If absent, check the OBS log for `melton-dual-feed-recorder` load errors; confirm the DLL is in `obs-plugins\64bit` and OBS is 64-bit 32.x.
* **"Not enough free disk space"**: start requires 2 GB free in the destination drive.
* **CLEAN: STOPPED right after Start**: read the red message in the dock and the OBS log. With encoder "Auto" a failing hardware encoder falls back to x264 automatically and logs it.
* **Graphics still in CLEAN**: tick the exact source in Graphics exclusion (check "Scene structure" tab, excluded entries are marked). A graphic baked into a camera source cannot be removed.
* **Wrong/missing audio in CLEAN**: set "OBS audio track" to the track your dirty recording uses (OBS Settings -> Output -> Recording -> Audio Track), and make sure your sources are routed to that track in Advanced Audio Properties.
* **Frames lost warning**: lower resolution/FPS, use a hardware encoder, or close GPU-heavy apps. The clean feed adds one extra render and one extra encode.
* **Clean FPS lower than chosen**: it cannot exceed OBS's FPS.
* **Transition looks different / cuts**: see Known limitations in the README.
* **Configure fails on dependency hash**: see "Status of this delivery" in the README.
